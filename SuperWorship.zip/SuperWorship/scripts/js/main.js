// // JavaScript Code For Super Worship

// var TopDisleft = document.getElementsByClassName('eas-top-display')[0].style.backgroundImage = "url('images/city.JPG')";



// function GetElemId(elem) {
// 	return document.getElementById(Elem);
// }
// function GetImgSrc(elem) {
// 	return elem.src;
// }
// function ChangeBg(elem,imageSrc) {
// 	return elem.style.backgroundImage = "url('"imageSrc"')";
// }
// function AddEvent(elem,evt,funcc) {
// 	return elem.addEventListener(evt,funcc);
// }


